// Student name: (put your name here)
// Student ID: (put your ID number here)

function BST()
{
    // your code here
}

// and more of your code down here

// Student name: (put your name here)
// Student ID: (put your ID number here)

// Don't forget to include the .js file for the base class along with
// this one when submitting to Blackboard!

function Set489()
{
    // your code here
}

// and more of your code down here

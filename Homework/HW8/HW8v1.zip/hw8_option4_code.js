// Student name: (put your name here)
// Student ID: (put your ID number here)

// You will create and submit several other .js files for 
// this assignment. This file just contains the primary 
// functions called by the script in the .html file.

function MergeSort(array)
{
	// Implement synchronous, single-threaded merge sort here.
	// You may want to add paramaters to this function or make a helper 
	// function. Just make that this function can be called with only 
	// 1 parameter.
}

function QuickSort(array)
{
	// Implement synchronous, single-threaded quick sort here.
	// You may want to add paramaters to this function or make a helper 
	// function. Just make that this function can be called with only 
	// 1 parameter.
}

function MergeSortAsync(array, completionCallback)
{
    // Implement asynchronous, multi-threaded sort with web workers in 
    // accordance with assignment instructions. Invoke the completion 
    // callback function when sort has finished (0 parameters).
}

function QuickSortAsync(array, completionCallback)
{
    // Implement asynchronous, multi-threaded sort with web workers in 
    // accordance with assignment instructions. Invoke the completion 
    // callback function when sort has finished (0 parameters).
}
